<?PHP
/*
=====================================================
 DataLife Engine v10.1
-----------------------------------------------------
 Persian Support Site: http://datalifeengine.ir
-----------------------------------------------------
 English Support Site: http://datalifeengine.net
-----------------------------------------------------
 Copyright (c) 2006-2013, All Right Reserved.
=====================================================
*/

if( ! defined( 'DATALIFEENGINE' ) ) {
	die( "Hacking attempt!" );
}

msgbox("info","Upgrade is completed", "Congratulation! Your website has been completely upgraded to the current version <b>$version_id</b>.<br /><br /> Please delete folder <b>/upgrade/</b> from your server! You can now view the page <a href=\"../index.php\">Home Page</a> and make sure that you have have upgraded your theme to support and compatible with DLE <b>$version_id</b>!");

?>
<?PHP
/*
=====================================================
 DataLife Engine v10.1
-----------------------------------------------------
 Persian Support Site: http://datalifeengine.ir
-----------------------------------------------------
 English Support Site: http://datalifeengine.net
-----------------------------------------------------
 Copyright (c) 2006-2013, All Right Reserved.
=====================================================
*/

if( ! defined( 'DATALIFEENGINE' ) ) {
	die( "Hacking attempt!" );
}

msgbox("info","Error", "Unable to identify your current DataLife Engine version, maybe support of this version has been discontinued. The upgrade process is stopped.");
?>
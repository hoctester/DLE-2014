<?PHP
/*
=====================================================
 DataLife Engine v10.1
-----------------------------------------------------
 Persian Support Site: http://datalifeengine.ir
-----------------------------------------------------
 English Support Site: http://datalifeengine.net
-----------------------------------------------------
 Copyright (c) 2006-2013, All Right Reserved.
=====================================================
*/

if(!defined('DATALIFEENGINE')) {
	die("Hacking attempt!");
}

if ($action == "sort" || $action == "delete" || $_POST['obmen-submit']) {
	@unlink( ENGINE_DIR . '/cache/system/obmen.php' );
}

$js_array[] = "engine/skins/obmen/colorpicker.js";
$colorPicker = <<<HTML
<link rel="stylesheet" media="screen" type="text/css" href="engine/skins/obmen/colorpicker.css" />
<script type="text/javascript">
\$('#colorSelector').ColorPicker({
	color: \$('#colorSelector').val(),
	onShow: function (colpkr) {
		\$(colpkr).fadeIn(500);
		return false;
	},
	onHide: function (colpkr) {
		\$(colpkr).fadeOut(500);
		return false;
	},
	onChange: function (hsb, hex, rgb) {
		\$('#colorSelector').val(hex);
	}
});
</script>
HTML;

if ($action == "edit") {

	if( isset($_POST['obmen-submit']) AND ($_POST['obmen-submit'] == "true") ){
		$id = $db->safesql(intval($_REQUEST['id'])); 
		$title = $db->safesql(stripslashes($_POST['title']));
		$color = $db->safesql(stripslashes($_POST['color']));
		$bold = $db->safesql(stripslashes($_POST['bold']));
		$link = $db->safesql(stripslashes($_POST['link']));
		$mail = $db->safesql(stripslashes($_POST['mail']));
		$icq = $db->safesql(stripslashes($_POST['icq']));
		$posit = $db->safesql(stripslashes($_POST['posit']));
		$target = $db->safesql(stripslashes($_POST['target']));
		$description = $db->safesql(substr(strip_tags(stripslashes($_REQUEST['description'])), 0, 350));
		$db->query("UPDATE " . PREFIX . "_obmen set title='$title', color='$color', bold='$bold', link='$link', icq='$icq', mail='$mail', description='$description', posit='$posit', target='$target' where id='$id'");
		msg("info", "Information", "{$title} successfully updated.", "$PHP_SELF?mod=obmen");
	} else {
		echoheader("obmen", $lang['opt_obmen']);

		$db->query("SELECT * FROM " . PREFIX . "_obmen WHERE id=" . (int)$_REQUEST['id'] . " ORDER BY posit ASC");
		$row = $db->get_row();

		if ($row["bold"]) $boldchecked = " checked=\"true\"";
		
		if ($row["target"] == "_blank") $blankselected = " selected=\"true\"";
		if ($row["target"] == "_top") $topselected = " selected=\"true\"";
		
		$id = $row['id'];
		$title = $row['title'];
		$link = $row['link'];
		$color = $row['color'];
		$mail = $row['mail'];
		$icq = $row['icq'];
		$description = $row['description'];
		
		$posit = "";
		
		for($i = 0; $i <= 20; $i++){
			$posit .= "<option value=\"{$i}\"";
			$posit .= ($row['posit'] == $i) ? " selected=\"true\"" : "";
			$posit .= ">{$i}</option>";
		}
		
		echo <<<HTML
<form method="post" action="">
<div style="padding-top:5px;padding-bottom:2px;">
<table width="100%">
<tr>
<td width="4"><img src="engine/skins/images/tl_lo.gif" width="4" height="4" border="0"></td>
<td background="engine/skins/images/tl_oo.gif"><img src="engine/skins/images/tl_oo.gif" width="1" height="4" border="0"></td>
<td width="6"><img src="engine/skins/images/tl_ro.gif" width="6" height="4" border="0"></td>
</tr>
<tr>
<td background="engine/skins/images/tl_lb.gif"><img src="engine/skins/images/tl_lb.gif" width="4" height="1" border="0"></td>
<td style="padding:5px;" bgcolor="#FFFFFF">
<table width="100%">
<tr>
<td bgcolor="#EFEFEF" height="29" style="padding-left:10px;"><div class="navigation">Edit Link</div></td>
</tr>
</table>
<div class="unterline"></div>
<table width="100%">
<tr>
<td width="260" style="padding:4px;" class="option"><strong>Name:</strong><br/><span class="small">Example: Datalife Engine</span></td>
<td><input class="edit" value="{$title}" type="text" size="45" name="title" /></td>
</tr>
<tr>
<td colspan="2" background="engine/skins/images/mline.gif" height="1"></td>
</tr>
<tr>
<td style="padding:4px;" class="option"><strong>Link:</strong><br/><span class="small">Example: http://datalifeengine.net/</span></td>
<td><input class="edit ltr" value="{$link}" type="text" size="45" name="link" /></td>
</tr>
<tr>
<td colspan="2" background="engine/skins/images/mline.gif" height="1"></td>
</tr>
<tr>
<td style="padding:4px;" class="option"><strong>Description:</strong><br/></td>
<td><input class="edit" name="description" value="{$description}" size="65" /></td>
</tr>
<tr>
<td colspan="2" background="engine/skins/images/mline.gif" height="1"></td>
</tr>
<tr>
<td style="padding:4px;" class="option"><strong>E-Mail Of Webmaster:</strong></td>
<td><input class="edit ltr" value="{$mail}" type="text "size="45" name="mail" /></td>
</tr>
<tr>
<td style="padding:4px;" class="option"><strong>Position:</strong></td>
<td><select name="posit" class="edit">{$posit}</select></td>
</tr>
<tr>
<td colspan="2" background="engine/skins/images/mline.gif" height="1"></td>
</tr>
<tr>
<td style="padding:4px;" class="option"><strong>Target:</strong></td>
<td>
<select name="target" class="edit">
<option value="">None</option>
<option value="_blank"{$blankselected}>In New Tab (_blank)</option>
<option value="_top"{$topselected}>Current Tab (_top)</option>
</select>
</td>
</tr>
<tr>
<td colspan="2" background="engine/skins/images/mline.gif" height="1"></td>
</tr>
<tr>
<td style="padding:4px;" class="option"><strong>Color:</strong></td>
<td>
<input class="edit" name="color" id="colorSelector" maxlength="6" size="6" value="{$color}" /> #
</td>
</tr>
<tr>
<td style="padding:4px;" class="option"><strong>Bold:</strong></td>
<td><input type="checkbox" name="bold" value="1" id="bold"{$boldchecked}><label for="bold"> <b>Yes</b></label></td>
</tr>
<tr>
<td colspan="2"><div class="hr_line"></div></td>
</tr>
<tr>
<td style="padding:4px;"><input type="submit" class="buttons" value=" Save  " /> <input onclick="confirmdelete();return false" type="button" class="buttons" value=" Delete Link " /> <a href="$PHP_SELF?mod=obmen">Back</a>
<td>&nbsp;</td>
</tr>
</table>
</td>
<td background="engine/skins/images/tl_rb.gif"><img src="engine/skins/images/tl_rb.gif" width="6" height="1" border="0"></td>
</tr>
<tr>
<td><img src="engine/skins/images/tl_lu.gif" width="4" height="6" border="0"></td>
<td background="engine/skins/images/tl_ub.gif"><img src="engine/skins/images/tl_ub.gif" width="1" height="6" border="0"></td>
<td><img src="engine/skins/images/tl_ru.gif" width="6" height="6" border="0"></td>
</tr>
</table>
</div>
<input name="obmen-submit" value="true" type="hidden">
</form>
<script type="text/javascript">
<!--
function confirmdelete(){
	DLEconfirm("آیا واقعا میخواهید این لینک را حذف کنید؟" ,"حذف لینک",function(){
		document.location="{$PHP_SELF}?mod=obmen&action=delete&id={$id}";
	});
}
//-->
</script>
HTML;

		echo $colorPicker;
		echofooter();
	}
} elseif ($action == "sort") {
	foreach ($_POST["posit"] as $id => $posit) {
		if($posit != "") {
			$posi = intval($posit);
			$id = intval($id);
			$query = $db->query("UPDATE " . PREFIX . "_obmen SET posit=$posi WHERE id = $id");
		}
	}
	msg("info", "Information", "Links ordered successfully.", "{$PHP_SELF}?mod=obmen");

} elseif ($action == "add") {

	if( isset($_POST['obmen-submit']) AND ($_POST['obmen-submit'] == "true") ){
		$title = $db->safesql(stripslashes($_POST['title']));
		$color = $db->safesql(stripslashes($_POST['color']));
		$bold = $db->safesql(stripslashes($_POST['bold']));
		$link = $db->safesql(stripslashes($_POST['link']));
		$mail = $db->safesql(stripslashes($_POST['mail']));
		$icq = $db->safesql(stripslashes($_POST['icq']));
		$target = $db->safesql(stripslashes($_POST['target']));
		$description = $db->safesql(substr(strip_tags(stripslashes($_REQUEST['description'])), 0, 350));
		$sql_insert = $db->query("INSERT INTO " . PREFIX . "_obmen (title, color, bold, link, icq, mail, description, target) values ('$title', '$color', '$bold', '$link', '$icq', '$mail', '$description', '$target')");
		msg("info", "Information", "{$title} successfully added.", "{$PHP_SELF}?mod=obmen");
	} else {
		echoheader("obmen", $lang['opt_obmen']);
		
		$posit = "";
		
		for($i = 0; $i <= 20; $i++){
			$posit .= "<option value=\"{$i}\">{$i}</option>";
		}
		
		echo <<<HTML
<form method="post" action="">
<div style="padding-top:5px;padding-bottom:2px;">
<table width="100%">
<tr>
<td width="4"><img src="engine/skins/images/tl_lo.gif" width="4" height="4" border="0"></td>
<td background="engine/skins/images/tl_oo.gif"><img src="engine/skins/images/tl_oo.gif" width="1" height="4" border="0"></td>
<td width="6"><img src="engine/skins/images/tl_ro.gif" width="6" height="4" border="0"></td>
</tr>
<tr>
<td background="engine/skins/images/tl_lb.gif"><img src="engine/skins/images/tl_lb.gif" width="4" height="1" border="0"></td>
<td style="padding:5px;" bgcolor="#FFFFFF">
<table width="100%">
<tr>
<td bgcolor="#EFEFEF" height="29" style="padding-left:10px;"><div class="navigation">Insert New Link</div></td>
</tr>
</table>
<div class="unterline"></div>
<table width="100%">
<tr>
<td width="260" style="padding:4px;" class="option"><strong>Name:</strong><br/><span class="small">Example: Datalife Engine</span></td>
<td><input class="edit" value="" type="text" size="45" name="title" /></td>
</tr>
<tr>
<td colspan="2" background="engine/skins/images/mline.gif" height="1"></td>
</tr>
<tr>
<td style="padding:4px;" class="option"><strong>Link:</strong><br/><span class="small">Example: http://datalifeengine.net/</span></td>
<td><input class="edit ltr" value="" type="text" size="45" name="link" /></td>
</tr>
<tr>
<td colspan="2" background="engine/skins/images/mline.gif" height="1"></td>
</tr>
<tr>
<td style="padding:4px;" class="option"><strong>Description:</strong></td>
<td><input class="edit" name="description" value="" size="65" /></td>
</tr>
<tr>
<td colspan="2" background="engine/skins/images/mline.gif" height="1"></td>
</tr>
<tr>
<td style="padding:4px;" class="option"><strong>E-Mail Of Webmaster:</strong></td>
<td><input class="edit ltr" value="" type="text "size="45" name="mail" /></td>
</tr>
<tr>
<td style="padding:4px;" class="option"><strong>Position:</strong></td>
<td><select name="posit" class="edit">{$posit}</select></td>
</tr>
<tr>
<td colspan="2" background="engine/skins/images/mline.gif" height="1"></td>
</tr>
<tr>
<td style="padding:4px;" class="option"><strong>Target:</strong></td>
<td>
<select name="target" class="edit">
<option value="">None</option>
<option value="_blank">In New Tab (_blank)</option>
<option value="_top">Current Tab (_top)</option>
</select>
</td>
</tr>
<tr>
<td colspan="2" background="engine/skins/images/mline.gif" height="1"></td>
</tr>
<tr>
<td style="padding:4px;" class="option"><strong>Color:</strong></td>
<td>
<input class="edit" name="color" id="colorSelector" maxlength="6" size="6" value="" /> #
</td>
</tr>
<tr>
<td style="padding:4px;" class="option"><strong>Bold?</strong></td>
<td><input type="checkbox" name="bold" value="1" id="bold"><label for="bold"> <b>Yes</b></label></td>
</tr>
<tr>
<td colspan="2"><div class="hr_line"></div></td>
</tr>
<tr>
<td style="padding:4px;"><input type="submit" class="buttons" value=" Add New Link  " /> <a href="$PHP_SELF?mod=obmen">Back</a>
<td>&nbsp;</td>
</tr>
</table>
</td>
<td background="engine/skins/images/tl_rb.gif"><img src="engine/skins/images/tl_rb.gif" width="6" height="1" border="0"></td>
</tr>
<tr>
<td><img src="engine/skins/images/tl_lu.gif" width="4" height="6" border="0"></td>
<td background="engine/skins/images/tl_ub.gif"><img src="engine/skins/images/tl_ub.gif" width="1" height="6" border="0"></td>
<td><img src="engine/skins/images/tl_ru.gif" width="6" height="6" border="0"></td>
</tr>
</table>
</div>
<input name="obmen-submit" value="true" type="hidden">
</form>
HTML;

		echo $colorPicker;
		echofooter();
	}
} elseif ($action == "delete") {
	$db->query ("DELETE FROM " . PREFIX . "_obmen WHERE id = '{$_REQUEST['id']}'");
	msg("info", "Information", "The link was removed successfully.", "$PHP_SELF?mod=obmen");

} else {

	echoheader("obmen", $lang['opt_obmen']);
	echo <<<HTML
<script type="text/javascript">
<!--
function check_rang( host, id ){
ShowLoading("");
\$.post("{$config['http_home_url']}engine/ajax/rangsite.php",{'idsea':host},function(a){\$('#rang-'+id).fadeOut('normal',function(){\$(this).html(a).fadeIn();HideLoading("");});});
return false;
}
function MenuBuild( m_id, led_action, host ){

var menu=new Array()

menu[0]='<a href="{$PHP_SELF}?mod=obmen&action=edit&id=' + m_id + '">Edit</a>';
menu[1]='<a href="#" onclick="check_rang(\'' + host + '\', ' + m_id + '); return(false)">Get Google Rank</a>';
menu[2]='<a href="#" onclick="confirmdelete(' + m_id + '); return(false)">Delete</a>';

return menu;
}
function confirmdelete(id){
DLEconfirm("Do you really want to delete this link?","Delete Link",function(){
document.location="{$PHP_SELF}?mod=obmen&action=delete&id="+id;
});
}
//-->
</script>
HTML;
	$result = $db->query("SELECT * FROM " . PREFIX . "_obmen ORDER BY posit ASC");
	while($row = $db->get_row($result)) {
		$link = $row['link'];
		$id = $row['id'];
		$title = $row['title'];
		$color = $row['color'];
		$bold = $row['bold'];
		$mail = $row['mail'];
		$posit = $row['posit'];
		$icq = $row['icq'];
		$description = $row['description'];

		$che = parse_url("$link");
		$host = $che['host'];

		$entry .= <<<HTML
<tr>
<td width="60"><input name="posit[{$id}]" value="{$posit}" class="edit" size="2" />&nbsp;</td>
<td style="padding:2px"><a href="{$PHP_SELF}?mod=obmen&action=edit&id={$id}">{$title}</a></td>
<td style="padding:2px"><a href="{$link}" target="_blank">{$host}</a></td>
<td width="250"><span id="rang-{$id}">---</span></td>
<td width="60"><a onClick="return dropdownmenu(this, event, MenuBuild('{$row['id']}', 'off', '{$host}'), '150px')" href="#"><img src="engine/skins/images/browser_action.gif" border="0"></a></td>
</tr>
<tr><td background=engine/skins/images/mline.gif height="1" colspan="5"></td></tr>
HTML;
	}

	if ($_POST['action'] == "send_notice") {
		
		$obmen_config = array();
		
		foreach($_POST as $name => $value){
			if($name == "action") continue;
			$obmen_config[$name] = $_POST[$name];
		}
		
		$f = fopen( ENGINE_DIR . "/data/obmen.php", 'w' );
		fwrite( $f, serialize($obmen_config) );
		fclose( $f );
	}

	$obmen_config = unserialize( @file_get_contents( ENGINE_DIR . "/data/obmen.php" ));

	$text1 = $obmen_config['text']['1'];
	$text2 = $obmen_config['text']['2'];
	$showchecked1 = $obmen_config['showchecked']['1'];
	$showchecked2 = $obmen_config['showchecked']['2'];
	$showchecked3 = $obmen_config['showchecked']['3'];

	if ( $showchecked1 == '1' ) $ifchecked1 = "checked";
	if ( $showchecked2 == '1' ) $ifchecked2 = "checked";

	if ($showchecked3 == '1' ) $ifchecked3 = "checked";
	
	echo <<<HTML
<table width="100%">
<tr>
<td width="4"><img src="engine/skins/images/tl_lo.gif" width="4" height="4" border="0"></td>
<td background="engine/skins/images/tl_oo.gif"><img src="engine/skins/images/tl_oo.gif" width="1" height="4" border="0"></td>
<td width="6"><img src="engine/skins/images/tl_ro.gif" width="6" height="4" border="0"></td>
</tr>
<tr>
<td background="engine/skins/images/tl_lb.gif"><img src="engine/skins/images/tl_lb.gif" width="4" height="1" border="0"></td>
<td style="padding:5px;" bgcolor="#FFFFFF"><table width="100%">
<tr>
<td bgcolor="#EFEFEF" height="29" style="padding-left:10px;"><div class="navigation"><table width=100% class=navigation>
<tr><td>Links List</td><td align=left style='font-size: 9px'></td></tr></table></div></td>
</tr>
</table>
<div class="unterline"></div><form method="post" action="$PHP_SELF?mod=obmen&action=sort">
<table width=100% border=0 cellspacing=0 cellpadding=0>
HTML;
	
	if ($entry) $entry = <<<HTML
<tr>
<td>Position:</td>
<td style="padding:2px">Name:</td>
<td style="padding:2px">Link:</td>
<td width="250">Google Rank:</td>
<td width="60">Function:</td>
</tr>
<tr>
<td background=engine/skins/images/mline.gif height="1" colspan="5"></td>
</tr>
{$entry}
HTML;
	else $entry = "<tr><td align=\"center\" height=\"30\" colspan=\"5\" align=\"center\" class=\"navigation\">- There is no link to show -</td></tr>";
	$row = $db->super_query("SELECT COUNT(*) as count FROM " . PREFIX . "_obmen");
	$sites = $row['count'];
	echo <<<HTML
{$entry}
</table>
<div class="hr_line"></div><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left">
<input type='button' value=' Add new link ' class='bbcodes' onclick="window.location='$PHP_SELF?mod=obmen&action=add'">
<input type='button' value=' Settings ' class='bbcodes' onclick="javascript:ShowOrHide('options')">
<input type="submit" value=' Order links ' class='bbcodes'>
</td>
<td class="navigation" align="right">Number of the links: <b>{$sites}</b></td>
</tr>
</table></form>
</td>
<td background="engine/skins/images/tl_rb.gif"><img src="engine/skins/images/tl_rb.gif" width="6" height="1" border="0"></td>
</tr>
<tr>
<td><img src="engine/skins/images/tl_lu.gif" width="4" height="6" border="0"></td>
<td background="engine/skins/images/tl_ub.gif"><img src="engine/skins/images/tl_ub.gif" width="1" height="6" border="0"></td>
<td><img src="engine/skins/images/tl_ru.gif" width="6" height="6" border="0"></td>
</tr>
</table>

<div id="options" style="display:none;">
<form method="post" action="">
<input type="hidden" name="action" value="send_notice">
<div style="padding-top:5px;padding-bottom:2px;">
<table width="100%">
<tr>
<td width="4"><img src="engine/skins/images/tl_lo.gif" width="4" height="4" border="0"></td>
<td background="engine/skins/images/tl_oo.gif"><img src="engine/skins/images/tl_oo.gif" width="1" height="4" border="0"></td>
<td width="6"><img src="engine/skins/images/tl_ro.gif" width="6" height="4" border="0"></td>
</tr>
<tr>
<td background="engine/skins/images/tl_lb.gif"><img src="engine/skins/images/tl_lb.gif" width="4" height="1" border="0"></td>
<td style="padding:5px;" bgcolor="#FFFFFF">
<table width="100%">
<tr>
<td bgcolor="#EFEFEF" height="29" style="padding-left:10px;"><div class="navigation">Settings</div></td>
</tr>
</table>
<div class="unterline"></div>
<table width="100%">
<tr><td width=200>Text at top of the links:<br/><input type="checkbox" {$ifchecked1} name="showchecked[1]" value="1" id="check1"><label for="check1">Show</label></td>
<td><textarea name="text[1]" style="width:350px;height:70px;background-color:lightyellow;">{$text1}</textarea></td></tr>
<tr><td width=200>Text at bottom of the links:<br/><input type="checkbox" {$ifchecked2} name="showchecked[2]" value="1" id="check2"><label for="check2">Show</label></td>
<td><textarea name="text[2]" style="width:350px;height:70px;background-color:lightyellow;">{$text2}</textarea></td></tr>
<tr><td width=200>Moving:</td><td><input type="checkbox" {$ifchecked3} name="showchecked[3]" value="1" id="check3"><label for="check3">Move to the top</label></td></tr>
<tr><td width=200><br/></td><td><br/><input type="submit" class="buttons" value="Save" style="width:100px;"></td></tr>

</table>
</td>
<td background="engine/skins/images/tl_rb.gif"><img src="engine/skins/images/tl_rb.gif" width="6" height="1" border="0"></td>
</tr>
<tr>
<td><img src="engine/skins/images/tl_lu.gif" width="4" height="6" border="0"></td>
<td background="engine/skins/images/tl_ub.gif"><img src="engine/skins/images/tl_ub.gif" width="1" height="6" border="0"></td>
<td><img src="engine/skins/images/tl_ru.gif" width="6" height="6" border="0"></td>
</tr>
</table>
</div>
</form></div>
HTML;

	echofooter();
}

?>
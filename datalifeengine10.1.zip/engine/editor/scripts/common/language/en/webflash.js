﻿function loadTxt() {
    document.getElementById("lblSource").innerHTML = "SOURCE:";
    document.getElementById("lblWidth").innerHTML = "WIDTH:";
    document.getElementById("lblHeight").innerHTML = "HEIGHT:";
    document.getElementById("btnCancel").innerHTML = "cancel";
    document.getElementById("btnInsert").value = " insert ";
}

function writeTitle() {
    document.write("<title>Flash</title>")
}
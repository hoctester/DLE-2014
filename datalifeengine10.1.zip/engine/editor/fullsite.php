<?PHP
/*
=====================================================
 DataLife Engine v10.1
-----------------------------------------------------
 Persian Support Site: http://datalifeengine.ir
-----------------------------------------------------
 English Support Site: http://datalifeengine.net
-----------------------------------------------------
 Copyright (c) 2006-2013, All Right Reserved.
=====================================================
*/

if(!defined('DATALIFEENGINE'))
{
  die("Hacking attempt!");
}

$fullarea = <<<HTML
    <div class="wseditor"><textarea id="full_story" name="full_story" class="wysiwygeditor" style="width:98%;height:200px;">{full-story}</textarea></div>
HTML;

?>